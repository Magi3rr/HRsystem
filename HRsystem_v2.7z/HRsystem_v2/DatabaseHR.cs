namespace HR
{
    partial class DatabaseHRDataContext
    {
    }
}