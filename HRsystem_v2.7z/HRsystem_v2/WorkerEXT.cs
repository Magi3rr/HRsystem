﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HR
{
    partial class Worker
    {
        public override string ToString()
        {
            return Imie  + DataUrodzenia;
        }
    }

    partial class LogIn
    {
        
            
    }

    

}
